let temperatureC = prompt('Введите температуру в градусах Цельсия'); // получение данных от пользователя
temperatureF = (9 / 5) * temperatureC + 32 ; // перевод в градусы Фаренгейта
alert(`Цельсий: ${temperatureC}, Фаренгейт: ${temperatureF}`); // вывод alert